# dock-window-preview
# Dock Window Preview (GNOME 46/49/50/51)

This GNOME Shell extension shows open-window previews when you hover a dock icon.
Clicking a preview activates that window; middle-clicking a preview closes that
window, like the Windows taskbar.

## Install locally

1. Run:
   `make install`
2. Reload GNOME Shell:
   - GNOME 50/51 / Wayland: log out and back in
   - GNOME 46/49 / X11: press `Alt+F2`, run `r`
   - GNOME 46 / Wayland: log out and back in
3. Enable the extension:
   `gnome-extensions enable dock-window-preview@quivio`
4. Open settings:
   `gnome-extensions prefs dock-window-preview@quivio`

## Make targets

- `make install`: installs to `~/.local/share/gnome-shell/extensions/dock-window-preview@quivio`
- `make zip`: creates `dist/dock-window-preview@quivio.zip`
- `make uninstall`: runs `./uninstall.sh` to disable (if possible) and remove the local install directory

You can override the install location:
`make install INSTALL_DIR=/path/to/extensions/dock-window-preview@quivio`

Direct script usage:
`UUID=dock-window-preview@quivio INSTALL_DIR=~/.local/share/gnome-shell/extensions/dock-window-preview@quivio ./uninstall.sh`

## Notes

- Supports GNOME Shell 46, 49, 50, and 51 (`shell-version: ["46", "49", "50", "51"]`).
- GNOME Shell 50 and later are Wayland-only, so a full log out / log in cycle is required after install.
- Includes a preferences panel for:
  - Hover delay (ms)
  - Vertical or horizontal preview layout
  - Preview thumbnail width/height
  - Title overflow behavior (truncate or wrap)
  - Optional per-window close button with left/right placement
  - Middle-click on a preview to close the window (enabled by default)
- The hover detector is tuned for dash/dock icons and uses the same app-window model as dock menu entries (including the "All Windows" behavior).
